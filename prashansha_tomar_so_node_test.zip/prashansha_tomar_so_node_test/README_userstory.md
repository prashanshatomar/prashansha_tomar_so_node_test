#  Parse invoice numbers

It's a node service to parse invoice numbers including file.

## Getting Started


### Prerequisites

Preinstallation :
  Nodejs must be installed


### Installing

To run this node service here are step by step series of examples that tell you how to get a development env running
```
1.Unzip and go inside UserStory project folder.
``````

``````
2.Open terminal and run "npm install". It will install all required dependencies.
``````
``````
3.After installing all dependency, start the server by running "npm run start". Server started on http://localhost:3000.
``````
``````
4.Upload the input_user_story_1.txt file and the generated file will be store inside textfiles folder.
``````

## Authors

* **Prashansha Tomar** 

## License

This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.md) file for details


