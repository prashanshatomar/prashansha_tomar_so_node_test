var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var cors = require('cors');
var path = require('path');

// var apphtml = require(__dirname+'/public/app.html');

var config = require('./config.json');

//port number
var port = process.env.PORT || 3000;

//express app object
var app = express();

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

var apiRoutes = express.Router();

//Adding middleware, to add middleware we need cors, nody-parser
app.use(cors());

//static files
// app.use(express.static(path.join(__dirname)));

//For creating route to home page
app.get('/', (req, res) => {
    // res.send('ScheduleOnce assignment answers');
    res.sendFile(__dirname+'/public/app.html');
});

//Initialize an array
var arr = [];
var arr_len = 100000;

var four = 4;
var seven =7;


for (var i=1; i<=arr_len; i=i+1){

    if(((i%four) ==0) && ((i%seven)!=0)){
        arr.push('marco');
    }else if(((i%seven) == 0) && ((i%four)!=0)){
        arr.push('polo')
    }else if(((i%four) ==0) && ((i%seven) ==0)){
        arr.push('marcopolo')
    }else{
        arr.push(i)
    }
    
}

//Here all route api call with this particular route. eg. /SO/marcopologame
app.get('/marcopologame', (req, res) => {
    console.log('Inside Marco Polo Game Service-----------');  
    res.send(arr)
});


app.listen(port, (err) => {
    console.log('Web service server started at port: ' + port);
});
app.use('/', apiRoutes);