# prashansha_so_node_test

Marco Polo Game

## Getting Started


### Prerequisites

Preinstallation :
1. Nodejs must be installed


### Installing web service for Marco Polo Game

A step by step series of examples that tell you how to get a development env running for marco polo game service
```
1.Clone the project to your local machine.
``````
``````
2.Go inside the project folder that has been created.
``````
``````
3.Open terminal and run "npm install". It will install all required dependencies for backend.
``````
``````
4.After installing all dependency for backend, start the server by running "npm run start". Server started on http://localhost:3000.
``````


### When is it a good idea to not use NodeJs? Why? 

Not to use nodejs when : 
```
Not to use NodeJs when our project not need non-blocking io.
``````
``````
When project required only synchronize process only.
``````
``````
When project do not required peer to peer connection.
``````
## Authors

**Prashansha Tomar** 

## License

This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.md) file for details


